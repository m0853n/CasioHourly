package com.example.hourlybeep

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

class HourlyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("hourly", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        playBeep()
        HourlyScheduler.scheduleNext(context)
    }

    companion object {
        fun playBeep() {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 180)
            Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 300)
        }
    }
}
