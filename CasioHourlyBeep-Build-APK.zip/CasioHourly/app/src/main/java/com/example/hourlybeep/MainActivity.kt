package com.example.hourlybeep

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("hourly", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        updateUi()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(244, 245, 240))
        }
        val title = TextView(this).apply {
            text = "بیپ ساعتی"
            textSize = 30f
            setTextColor(Color.rgb(34, 45, 36))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "یادآوری گذشت هر یک ساعت، مثل ساعت کاسیو"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 28)
        }
        status = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.rgb(46, 125, 50))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        toggle = Button(this).apply {
            textSize = 18f
            setOnClickListener { toggleAlarm() }
        }
        val test = Button(this).apply {
            text = "پخش صدای آزمایشی"
            setOnClickListener { HourlyReceiver.playBeep(); Toast.makeText(this@MainActivity, "بیپ آزمایشی", Toast.LENGTH_SHORT).show() }
        }
        val note = TextView(this).apply {
            text = "برای کارکرد در پس‌زمینه، یادآوری‌ها در رأس هر ساعت اجرا می‌شوند. پس از راه‌اندازی مجدد گوشی، برنامه وضعیت قبلی را بازیابی می‌کند."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title, lp())
        root.addView(subtitle, lp())
        root.addView(status, lp())
        root.addView(toggle, lp())
        root.addView(test, lp())
        root.addView(note, lp())
        setContentView(root)
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }

    private fun toggleAlarm() {
        val enabled = prefs.getBoolean("enabled", false)
        if (enabled) {
            HourlyScheduler.cancel(this)
            prefs.edit().putBoolean("enabled", false).apply()
            updateUi()
            return
        }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            Toast.makeText(this, "اجازهٔ زمان‌بندی دقیق را بده و دوباره دکمه را بزن", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putBoolean("enabled", true).apply()
        HourlyScheduler.scheduleNext(this)
        updateUi()
    }

    private fun updateUi() {
        val enabled = prefs.getBoolean("enabled", false)
        status.text = if (enabled) "● یادآوری ساعتی روشن است" else "○ یادآوری ساعتی خاموش است"
        toggle.text = if (enabled) "خاموش کردن یادآوری" else "روشن کردن یادآوری ساعتی"
    }
}
