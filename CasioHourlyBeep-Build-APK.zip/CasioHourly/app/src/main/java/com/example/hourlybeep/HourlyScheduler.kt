package com.example.hourlybeep

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object HourlyScheduler {
    fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, 101, Intent(context, HourlyReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("hourly", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val now = Calendar.getInstance()
        val next = (now.clone() as Calendar).apply {
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.HOUR_OF_DAY, 1)
        }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending(context))
        } catch (_: SecurityException) {
            alarm.set(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending(context))
        }
    }

    fun cancel(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pending(context))
    }
}
